
package ex1;

public class Prestamo {

	private String prestamo;
	
	public Prestamo(String prestamo) {
		this.prestamo=prestamo;
	}

	@Override
	public String toString() {
		return "Prestamo [prestamo=" + prestamo + "]";
	}

	
	
	
	
	
}
